package generated

//go:generate go-bindata -pkg generated -o ./bindata.go files/
