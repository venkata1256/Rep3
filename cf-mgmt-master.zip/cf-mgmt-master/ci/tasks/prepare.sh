#!/bin/bash -e
cp source/Dockerfile prepare-output/.
cp releases/cf-mgmt-linux prepare-output/.
cp releases/cf-mgmt-config-linux prepare-output/.
cp releases/version prepare-output/.
