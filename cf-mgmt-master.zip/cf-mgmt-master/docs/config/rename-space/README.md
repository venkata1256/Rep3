&larr; [back to Commands](../README.md)

# `cf-mgmt-config rename-space`

`rename-space` command will rename and update all space configuration files for a given org/space

## Command Usage
```
error: Usage:
  cf-mgmt-config [OPTIONS] rename-space [rename-space-OPTIONS]

Help Options:
  -h, --help            Show this help message

[rename-space command options]
  --config-dir= Name of the config directory (default: config) [$CONFIG_DIR]
  --org=        Org name
  --space=      Space name
  --new-space=  Space name to rename to
```
