&larr; [back to Commands](../README.md)

# `cf-mgmt version`

Displays version

## Command Usage

```
Usage:
  cf-mgmt [OPTIONS] version

Help Options:
  -h, --help      Show this help message
```
