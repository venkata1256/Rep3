package config

// ASGConfig describes is an array of Rules
type ASGConfig struct {
	Rules string
	Name  string
}
